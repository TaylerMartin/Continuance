﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class DeathCollider : MonoBehaviour
{
    public GameObject Player;

	// Use this for initialization
	void Start ()
    {
        
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Player == null)
        {
            Player = GameObject.FindGameObjectWithTag("Player");
        }
        transform.position = new Vector3(Player.transform.position.x, -20f, 0f);
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            //reload scene
            SceneManager.LoadScene(0, LoadSceneMode.Single);
        }       
    }
}
