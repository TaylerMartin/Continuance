﻿using UnityEngine;
using System.Collections;

public class Platform : MonoBehaviour
{
    public BoxCollider platformCollider;
    public Renderer platformRenderer;
    // Use this for initialization
    void Start () //check what type of platform it is and change its values accordingly
    {      
        if (transform.tag.Contains("Fixable"))
        {
            Destroy();
        } 
        else if(transform.tag.Contains("Destroyable"))
        {
            Fix();
        }
    }

    public void Fix()
    {
        //fixable platforms start with collision
        platformCollider.enabled = true;
        //change visuals
        platformRenderer.material.color = Color.green;
    }

    public void Destroy()
    {
        //destructable platforms start without collision
        platformCollider.enabled = false;
        //change visuals
        platformRenderer.material.color = Color.red;
    }

}
