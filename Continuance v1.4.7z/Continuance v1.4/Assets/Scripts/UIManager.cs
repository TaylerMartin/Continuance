﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class UIManager : MonoBehaviour {

    public Text TutorialTextReference;
    public Text DeathDistanceDisplayReference;

    public static Text TutorialText;
    public static Text DeathDistanceDisplay;

    // Use this for initialization
    void Start()
    {
        TutorialText = TutorialTextReference;
        DeathDistanceDisplay = DeathDistanceDisplayReference;
    }

    public static void RevertTutorial()
    {
        TutorialText.text = ("Press " + GameManager.KeyReverse + " to revert time and fix the ramp");
    }

    public static void AdvanceTutorial()
    {
        TutorialText.text = ("Press " + GameManager.KeyAccelerate + " to accelerate time and destroy this obstacle");
    }

    public static void CloseTutorial()
    {
        TutorialText.text = ("");
    }

    public static void UpdateDeathDistanceDisplay()
    {
        DeathDistanceDisplay.text = ("Distance to the End of the World: " + GameManager.deathDistance);
    }
}

