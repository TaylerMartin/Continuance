﻿using UnityEngine;
using System.Collections;
using System;


public class PlayerController : MonoBehaviour
{

    // Use this for initialization

    public float xSpeed;
    public float ySpeed;
    public bool onPlatform;
    Rigidbody PlayerRigidbody;

    public TimeSphere timeSphere;
    SphereCollider timeSphereCollider;

    float JumpForce = 7;

    private Collider PlayerCollider;

    

    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
        timeSphereCollider = timeSphere.GetComponent<SphereCollider>();
        PlayerCollider = GetComponent<CapsuleCollider>();

        StartCoroutine(CalcDeathDistance());
    }


    // Update is called once per frame
    void Update()
    {
        Movement();
        Vector3 pos = transform.position;
        

        if (Input.GetKey(GameManager.KeyAccelerate) &&
            timeSphereCollider.enabled == false) //expands the timeSphere
        {
            timeSphere.isAccelerate = true;
            timeSphere.GrowSphere();
        }
        if (Input.GetKeyUp(GameManager.KeyAccelerate))
        {
            timeSphere.ShrinkSphere();
        }

        if (Input.GetKey(GameManager.KeyReverse) &&
           timeSphereCollider.enabled == false) //expands the timeSphere
        {
            timeSphere.isAccelerate = false;
            timeSphere.GrowSphere();
        }
        if (Input.GetKeyUp(GameManager.KeyReverse))
        {
            timeSphere.ShrinkSphere();
        }

        transform.position = pos;
    }


    private void Movement()
    {
        float x = Input.GetAxis("Horizontal") * xSpeed;
        Vector3 velocity = PlayerRigidbody.velocity;
        velocity.x = x;
        PlayerRigidbody.velocity = velocity;

        if (Input.GetKey(GameManager.KeyJump) && onPlatform)
        {
            Jump();
        }
    }

    void Jump()
    {
        onPlatform = false;
        PlayerRigidbody.AddForce(Vector3.up * JumpForce, ForceMode.VelocityChange);
    }

    void OnCollisionEnter(Collision col) //when the player collides with something
    {
        if (col.gameObject.tag.Contains("Platform")) //if player collides with a platform the player can jump and move normally again
        {
            onPlatform = true;
        }
    }

    IEnumerator CalcDeathDistance()
    {
        while (true)
        {
            GameManager.deathDistance = Vector3.Distance(transform.position, GameManager.DeathWall.transform.position);
            UIManager.UpdateDeathDistanceDisplay();
            yield return new WaitForEndOfFrame();
        }
    }
}
