﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class FinishArea : MonoBehaviour
{

	// Use this for initialization
	void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player") //if player reaches the finish area they go to the next level
        {
            Debug.Log("you win");
            //load next level
        }
    }
}
