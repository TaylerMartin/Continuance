﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public static KeyCode KeyReverse = KeyCode.Q;
    public static KeyCode KeyAccelerate = KeyCode.E;
    public static KeyCode KeyJump = KeyCode.Space;

    // Use this for initialization
    void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
