﻿using UnityEngine;
using System.Collections;

public class StartArea : MonoBehaviour {


 
	// Use this for initialization
	void Start () //instantiate the player in the start area when scene loads
    {
        Instantiate(Resources.Load("Prefabs/Player"), transform.position, transform.rotation);
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
