﻿using UnityEngine;
using System.Collections;
using System;

public class PlayerController : MonoBehaviour {

    // Use this for initialization

    public float xSpeed;
    public float ySpeed;
    public bool onPlatform;
    Rigidbody rb;

    public GameObject AccelerateTimeSphere;
    public GameObject ReverseTimeSphere;



    float JumpVelocity;
    float JumpDampening = 0.05f;


    void Start ()
    {
        rb = GetComponent<Rigidbody>();
    }
	
     
	// Update is called once per frame
	void Update ()
    {
        Movement();
        Vector3 pos = transform.position;

        if (Input.GetKey(GameManager.KeyAccelerate) & ReverseTimeSphere.GetComponent<SphereCollider>().enabled == false) //expands the timeSphere
        {
            AccelerateTimeSphere.GetComponent<TimeSphere>().GrowSphere();
        }
        if (Input.GetKeyUp(GameManager.KeyAccelerate))
        {
            AccelerateTimeSphere.GetComponent<TimeSphere>().ShrinkSphere();
        }

        if (Input.GetKey(GameManager.KeyReverse) & AccelerateTimeSphere.GetComponent<SphereCollider>().enabled == false) //expands the timeSphere
        {
            ReverseTimeSphere.GetComponent<TimeSphere>().GrowSphere();
        }
        if (Input.GetKeyUp(GameManager.KeyReverse))
        {
            ReverseTimeSphere.GetComponent<TimeSphere>().ShrinkSphere();
        }

        if (JumpVelocity != 0)
        {
            pos.y += JumpVelocity;
            JumpVelocity -= JumpDampening;
            if (JumpVelocity <= 0)
            {
                rb.useGravity = true;
                JumpVelocity = 0;
            }
        }

        transform.position = pos;
    }

    private void Movement()
    {
        float x = Input.GetAxis("Horizontal") * xSpeed * Time.deltaTime;
        transform.Translate(x, 0, 0);
        
        if (Input.GetKey(GameManager.KeyJump) && onPlatform)
        {
            Jump();
        }
    }

    void Jump()
    {
        JumpVelocity = 0.4f;
        onPlatform = false;
    }

    void OnCollisionEnter(Collision col) //when the player collides with something
    {
        if (col.gameObject.tag.Contains("Platform")) //if player collides with a platform the player can jump and move normally again
        {
            onPlatform = true;
        } 
    }

}
