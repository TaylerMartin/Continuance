﻿using UnityEngine;
using System.Collections;

public class Platform : MonoBehaviour
{
    private BoxCollider platformCollider;
    private Renderer platformRenderer;
    private GameObject GameManagerReference; 

    // Use this for initialization
    void Start () //check what type of platform it is and change its values accordingly
    {
        platformCollider = GetComponent<BoxCollider>();
        platformRenderer = GetComponent<Renderer>();
        GameManagerReference = GameObject.FindGameObjectWithTag("GameController");

        if (transform.tag.Contains("Fixable"))
        {
            Destroy();
        } 
        else if(transform.tag.Contains("Destroyable"))
        {
            Fix();
        }
    }

    public void Fix()
    {
        //fixable platforms start with collision
        platformCollider.enabled = true;
        //change visuals
        platformRenderer.material = GameManagerReference.GetComponent<GameManager>().mats[0]; //i dont think this is very well implemented
        //platformRenderer.material.color = Color.green;
    }

    public void Destroy()
    {
        //destructable platforms start without collision
        platformCollider.enabled = false;
        //change visuals
        platformRenderer.material = GameManagerReference.GetComponent<GameManager>().mats[1];
        //platformRenderer.material.color = Color.red;
    }

}
