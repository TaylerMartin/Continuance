﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class DeathCollider : MonoBehaviour
{
    private GameObject Player;

	// Use this for initialization
	void Start ()
    {
        
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Player == null)
        {
            Player = GameObject.FindGameObjectWithTag("Player");
        }
        transform.position = new Vector3(Player.transform.position.x, -20f, 0f);
	}

    void OnTriggerEnter(Collider col)
    {
        Debug.Log("collided with something: " + col);
        if (col.tag.Contains("Player"))
        {
            //reload scene
            SceneManager.LoadScene(1, LoadSceneMode.Single);
        }       
    }
}
