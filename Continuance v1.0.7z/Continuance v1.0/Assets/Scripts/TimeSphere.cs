﻿using UnityEngine;
using UnityEngine.Events;
using System.Collections;

public class TimeSphere : MonoBehaviour
{
    public bool isAccelerate;
    public Vector3 MinimumSize;
    public Vector3 MaximumSize;
    public float sphereGrowth;
    public SphereCollider sphereCollider;
    KeyCode sphereKeyCode;
    KeyCode sphereKeyCode1;

    public void GrowSphere()
    {
        StopAllCoroutines();
        StartCoroutine(Grow());
    }

    public void ShrinkSphere()
    {
        StopAllCoroutines();
        StartCoroutine(Shrink());
    }

    IEnumerator Grow() //grows the sphere
    {
        sphereCollider.enabled = true; //enable the sphere collider so it can collide with platforms
        while (transform.localScale.x < MaximumSize.x)
        {
            transform.localScale += new Vector3(sphereGrowth, sphereGrowth, sphereGrowth);
            yield return new WaitForSeconds(0.01f);
        }
        transform.localScale = MaximumSize;
    }

    IEnumerator Shrink() //shrinks the sphere
    {
        while (transform.localScale.x > MinimumSize.x)
        {
            transform.localScale -= new Vector3(sphereGrowth, sphereGrowth, sphereGrowth);
            yield return new WaitForSeconds(0.01f);
        }
        transform.localScale = MinimumSize;
        sphereCollider.enabled = false; //when it is fully shrunk it must be disabled to stop collision with platforms when passing through them
    }

    void OnTriggerEnter(Collider col) 
    {
        switch (isAccelerate)
        {
            case true://this is the accelerate sphere
                if (col.tag.Contains("Destroyable")) //on colliding with a destroyable platform
                {
                    col.GetComponent<Platform>().Destroy(); //destroy the platform
                }
                break;

            case false://this is the reverse sphere
                if (col.tag.Contains("Fixable")) //on colliding with a fixable platform and this is the reverse sphere
                {
                    col.GetComponent<Platform>().Fix(); //fix the platform
                }
                break;

            default:          
                break;
        }     
    }

    void OnTriggerExit(Collider col)
    {
        switch (isAccelerate)
        {
            case true: //this is the accelerate sphere
                if (col.tag.Contains("Destroyable")) //on stopping colliding with a destroyable platform
                {
                    col.GetComponent<Platform>().Fix(); //destroy the platform
                }
                break;

            case false://this is the reverse sphere
                if (col.tag.Contains("Fixable")) //on stopping colliding with a fixable platform
                {
                    col.GetComponent<Platform>().Destroy(); //fix the platform
                }
                break;

            default:
                break;
        }
    }
}