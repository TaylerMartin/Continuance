﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public GameObject startPlatform;
    public GameObject player;
    public Camera _camera;
    public static KeyCode KeyReverse = KeyCode.Q;
    public static KeyCode KeyAccelerate = KeyCode.E;
    public static KeyCode KeyJump = KeyCode.Space;
    
    // Use this for initialization
    void Start ()
    {
        Instantiate(player, startPlatform.transform.position + player.transform.position, transform.rotation);
        Instantiate(_camera, _camera.transform.position, _camera.transform.rotation);
    }
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
