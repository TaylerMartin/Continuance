﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

    public GameObject player;
    Vector3 playerPos, targetPos;
    public float sweetSpotX, sweetSpotY, marginXR, marginXL, marginYB, marginYT, speed;

	// Use this for initialization
	void Start ()
    {
        player = GameObject.FindGameObjectWithTag("Player");
	}
	
	// Update is called once per frame
	void Update ()
    {
        playerPos = Camera.main.WorldToViewportPoint(player.transform.position);

        if (playerPos.x > sweetSpotX + marginXR) transform.Translate(speed,0,0);
        if (playerPos.x < sweetSpotX - marginXL) transform.Translate(-speed,0,0);
        if (playerPos.y > sweetSpotY + marginYB) transform.Translate(0, speed, 0);
        if (playerPos.y < sweetSpotY - marginYT) transform.Translate(0, -speed, 0);

        transform.position = Camera.main.ViewportToWorldPoint(targetPos);
	}
}
