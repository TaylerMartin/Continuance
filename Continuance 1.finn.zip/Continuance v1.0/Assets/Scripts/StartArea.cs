﻿using UnityEngine;
using System.Collections;

public class StartArea : MonoBehaviour {

    public GameObject player;

	// Use this for initialization
	void Start () //instantiate the player in the start area when scene loads
    {
        //Instantiate(player, player.transform.position, transform.rotation);
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
