﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class DeathCollider : MonoBehaviour
{

    public GameObject Player;

	// Use this for initialization
	void Start ()
    {
	    
	}
	
	// Update is called once per frame
	void Update ()
    {
        //transform.position = Player.transform.position;
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            //reload scene
            SceneManager.LoadScene("platform test1", LoadSceneMode.Single);
        }       
    }
}
